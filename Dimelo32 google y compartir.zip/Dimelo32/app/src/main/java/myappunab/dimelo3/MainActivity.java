package myappunab.dimelo3;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.UnsupportedSchemeException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    NfcAdapter nfcAdapter; //variable global para el NFC


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Manejo de NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter != null && nfcAdapter.isEnabled()) { //verifica que el NFC esté activado (previamente se solicitan permisos)


        }else {//verifica que el NFC está desactivado
            //Indica que se encienda el NFC si está desactivado
            Toast.makeText(this, "Active el NFC por favor!", Toast.LENGTH_LONG).show();

        }




    }


        //Declarar instancia NFC, importante para verificar interacción entre teléfono y etiqueta
        @Override
    protected void onNewIntent(Intent intent) {

            super.onNewIntent(intent);

            if(intent.hasExtra(NfcAdapter.EXTRA_TAG)){ //verifica la intención

                Toast.makeText(this, "NFC Intención!", Toast.LENGTH_SHORT).show();

                Parcelable[] parcelables = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES); //Instancia para ver el contenido de la etiqueta

                if(parcelables != null && parcelables.length > 0)//verifica que no esté vacía
                {
                    readTextFromMessage((NdefMessage) parcelables[0]);//Lee la etiqueta NFC
                }else{
                    Toast.makeText(this, "No NDEF messages found!", Toast.LENGTH_SHORT).show();//La etiqueta estpa vacía o no se puede mostrar
                }


               // Intent intent2 = new Intent(view.getContext(), ScrollingActivity.class); //declaro una intención de ir art la clase scrollingactivity

                //intent.putExtra("info", textinfo.getText().toString());//declaro variable que se comparte con la siguiente actividad

                //startActivity(intent2); //inicio la actividad


                //Esta parte está comentada porque sólo está implementada la etapa de lectura de etiqueta
                //Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                //NdefMessage ndefMessage = createNdefMessage("My string content!");
               // writeNdefMessage(tag, ndefMessage);
            }


    }

    private void readTextFromMessage(NdefMessage ndefMessage) { //método para leer le mensaje

        NdefRecord[] ndefRecords = ndefMessage.getRecords(); //

        if (ndefRecords != null && ndefRecords.length>0){//verifica que el mensaje no esté vacío

            NdefRecord ndefRecord = ndefRecords [0];

            String tagContent = getTextFromNdefRecord(ndefRecord);//guarda el contenido de la etiqueta en tagcontent

            Intent intent2 = new Intent(this, ScrollingActivity.class); //declaro una intención de ir art la clase scrollingactivity

            intent2.putExtra("info", tagContent);//declaro variable que se comparte con la siguiente actividad

            startActivity(intent2); //inicio la actividad



        }else{

            Toast.makeText(this, "No NDEF records found!", Toast.LENGTH_SHORT).show();

        }

    }


    @Override
    protected void onResume() {
        super.onResume();

        enableForegroundDispatchSystem();
    }

    @Override
    protected void onPause() {
        super.onPause();

        disableForegroundDispatchSystem();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private void enableForegroundDispatchSystem(){

        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        IntentFilter[] intentFilters = new IntentFilter[]{};

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, null);

    }

    private void disableForegroundDispatchSystem(){

    nfcAdapter.disableForegroundDispatch(this);
    }

    private void formarTag(Tag tag, NdefMessage ndefMessage){

        try{

            NdefFormatable ndefFormatable = NdefFormatable.get(tag);

            if(ndefFormatable == null){
                Toast.makeText(this, "El Tag no se puede formatear!",Toast.LENGTH_SHORT).show();
                return;
            }

            ndefFormatable.connect();
            ndefFormatable.format(ndefMessage);
            ndefFormatable.close();

            Toast.makeText(this, "El tag fue escrito", Toast.LENGTH_SHORT).show();

        }catch(Exception e){

            Log.e("FormatTag", e.getMessage());

        }

    }


    private void writeNdefMessage(Tag tag, NdefMessage ndefMessage){ // escribir mensaje, aunque aún no se ha habilitado la opción


        try {

            if (tag == null){


                Toast.makeText(this, "El tag no puede estar vacío", Toast.LENGTH_SHORT).show();
                return;

            }


            Ndef ndef = Ndef.get(tag);

            if (ndef == null){

                //formatea y escribe el mensaje
                formarTag(tag, ndefMessage);
            } else {

                ndef.connect();

                if (!ndef.isWritable()){
                    Toast.makeText(this, "El tag no se puede escribir", Toast.LENGTH_SHORT).show();
                    ndef.close();
                    return;


                }


                ndef.writeNdefMessage(ndefMessage);
                ndef.close();

                Toast.makeText(this, "El tag fue escrito", Toast.LENGTH_SHORT).show();



            }



        } catch (Exception e){


            Log.e("writeNdefMessage", e.getMessage());
        }




    }

    private NdefRecord createTextRecord(String content) { //para guardar el texto de un formato art otro

        try{

            byte[] language;
            language = Locale.getDefault().getLanguage().getBytes("UTF-8");

            final byte[] text = content.getBytes("UTF-8");
            final int languageSize = language.length;
            final int textLength = text.length;
            final ByteArrayOutputStream payload = new ByteArrayOutputStream(1 + languageSize + textLength);

            payload.write((byte) (languageSize & 0x1F));
            payload.write(language, 0, languageSize);
            payload.write(text, 0, textLength);

            return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new  byte[0], payload.toByteArray());

        } catch (UnsupportedEncodingException e){

            Log.e("createTextRecord", e.getMessage());



        }
        return  null;



    }



    private NdefMessage createNdefMessage(String content) { //para escribir

        NdefRecord ndefRecord = createTextRecord(content);

        NdefMessage ndefMessage = new NdefMessage(new NdefRecord[]{ ndefRecord });

        return ndefMessage;

    }

    public String getTextFromNdefRecord(NdefRecord ndefRecord) //para leer, obtiene el mensaje desde otro formato
    {
        String tagContent = null;
        try {
            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16";
            int languageSize = payload[0] & 0063;
            tagContent = new String(payload, languageSize + 1,
                    payload.length - languageSize - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("getTextFromNdefRecord", e.getMessage(), e);
        }
        return tagContent;
    }




}


        //Manejo de la interfaz gráfica
/*        final EditText textinfo, textname; //declaro el edittext
        textinfo = (EditText) findViewById(R.id.Tf_info); //Declaro cuál edittext tomo
        textname = (EditText) findViewById(R.id.Tf_name);

        ImageButton btn = (ImageButton) findViewById(R.id.Bt_nfc);

        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ScrollingActivity.class); //declaro una intención de ir art la clase scrollingactivity

                intent.putExtra("info", textinfo.getText().toString());//declaro variable que se comparte con la siguiente actividad
                intent.putExtra("name",textname.getText().toString());
                startActivity(intent); //inicio la actividad
            }
        });
*/













