package myappunab.dimelo3;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    NfcAdapter nfcAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Manejo de NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter != null && nfcAdapter.isEnabled()) {


        }




    }


        //Ver si se declara una instancia NFC (posible error)
        @Override
    protected void onNewIntent(Intent intent) {

        Toast.makeText(this,"NFC Intención funciona!", Toast.LENGTH_LONG).show();

        super.onNewIntent(intent);


    }

    @Override
    protected void onResume() {

        Intent intent = new Intent(this,MainActivity.class);
        intent.addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        IntentFilter[] intentFilter = new IntentFilter[] {};

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilter, null);

        super.onResume();


    }


    @Override
    protected void onPause() {

        nfcAdapter.disableForegroundDispatch(this);

        super.onPause();
    }



}


        //Manejo de la interfaz gráfica
/*        final EditText textinfo, textname; //declaro el edittext
        textinfo = (EditText) findViewById(R.id.Tf_info); //Declaro cuál edittext tomo
        textname = (EditText) findViewById(R.id.Tf_name);

        ImageButton btn = (ImageButton) findViewById(R.id.Bt_nfc);

        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ScrollingActivity.class); //declaro una intención de ir a la clase scrollingactivity

                intent.putExtra("info", textinfo.getText().toString());//declaro variable que se comparte con la siguiente actividad
                intent.putExtra("name",textname.getText().toString());
                startActivity(intent); //inicio la actividad
            }
        });
*/













