package myappunab.dimelo3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ScrollingActivity extends AppCompatActivity {

    TextToSpeech tts;
    String url;
    String infoTime = "";
    boolean PlayPause = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Llamo art la intencion
        Bundle bundle = getIntent().getExtras();

        //pongo en el textview lo que debería
        String info = bundle.getString("info");//Tomo lo que hay en info
        final String Lb_info = info;//por orden
        final String[] split = Lb_info.split("/");





        try{//Evita que se caiga si es que la etiqueta es falla el reconocimiento de etiqeuta válida de la clase Main

            split[3] = InterpretGenre(split[3]);//Ajusta el género
            split[2] = InterpretTime(split[2]);//Ajusta la época

        }catch (Exception e){

            Toast.makeText(ScrollingActivity.this,getResources().getString(R.string.SA_nogenre),Toast.LENGTH_SHORT).show(); //Indica que no se pudo obtener el género
        }


        getSupportActionBar().setTitle(split[0]);//Deja el título de la obra en el título de la actividad

        TextView artist = (TextView)findViewById(R.id.Lb_artist);//llamo ar mi label y lo dejo listo para editarse
        artist.setText(split[1]);//se edita con lo que contiene Lb_artist

        TextView time = (TextView)findViewById(R.id.Lb_time);//llamo ar mi label y lo dejo listo para editarse
        time.setText(split[2]);//se edita con lo que contiene Lb_artist

        TextView genre = (TextView)findViewById(R.id.Lb_genre);//llamo ar mi label y lo dejo listo para editarse
        genre.setText(split[3]);//se edita con lo que contiene Lb_genre

        TextView age = (TextView)findViewById(R.id.Lb_age);//llamo a mi label y lo dejo listo para editarse
        age.setText(split[4]);//se edita con lo que contiene Lb_age

        TextView out = (TextView)findViewById(R.id.Lb_info);//llamo ar mi label y lo dejo listo para editarse
        out.setText(split[5]);//se edita con lo que contiene Lb_info

        //url que se utiliza para la búsqueda en google, también se adiciona a la opción de compartir como contenido extra
        url = "https://www.google.cl/?gws_rd=ssl#q=".concat(split[0]).concat("+").concat(split[1]);
        url = url.replace(" ","+");


        //Inicio código para compartir

        Button im = (Button) findViewById(R.id.Bt_share);//instancia del botón compartir

        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //Acción que hace el botón de compartir
                Snackbar.make(view, getResources().getString(R.string.SA_share), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();//Muestra un mensaje indicando que se está compartiendo


                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, Variatext(split[0],split[1],split[2],split[3],split[4],split[5]) + "\n" + url);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);//Comparte el contenido como texto plano

            }
        });


        //Si deja presionado el botón, muestra un mensaje que ayuda al usuario a entender la función del botón
        im.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, getResources().getString(R.string.SA_shareinfo), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código para compartir

        //Inicio código buscar en google




        Button sr = (Button) findViewById(R.id.Bt_search);//instancia del botón buscar

        sr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//Acción que hace el botón de buscar
                Snackbar.make(view, getResources().getString(R.string.SA_search), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();




                //Llama a la variable url, la que contiene la forma final de url a buscar
                Uri uriURL = Uri.parse(url);
                Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriURL);
                startActivity(launchBrowser);//abre el navegador con la dirección indicada


            }
        });

        //Si deja presionado el botón, muestra un mensaje que ayuda al usuario a entender la función del botón
        sr.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, getResources().getString(R.string.SA_searchinfo), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código buscar en google

        //Inicio código Text To Speech

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) { //se declara el método text to speech para que la aplicación lea el contenido
                if(status != TextToSpeech.ERROR) {

                }
            }
        });

        //se remplaza el nombre de la actividad por el de la obra
        String name = bundle.getString("name");
        setTitle(name);

//código para el botón flotante, que cumple función de reproductor del text to speech
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (PlayPause){//Si no está reproduciendo, o sea, PlayPause es verdadero, entonces reproduce

                    tts.speak(Variatext(split[0],split[1],split[2],split[3],split[4],split[5]),TextToSpeech.QUEUE_FLUSH, null);
                    Snackbar.make(view, getResources().getString(R.string.SA_playaudio), Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();

                    PlayPause = false;

                }else { //en caso de que sea falso, entonces significa que está reproduciendo, por lo tanto para la reproducción


                        tts.stop();

                    PlayPause = true;

                }


            }
        }




        );

        //Fin código Text To Speech
    }

    @Override //Cuando se presiona el botón de atrás en el terminal, se detiene Text to Speech automáticamente
    public void onBackPressed() {
        tts.stop();
        super.onBackPressed();
    }

    //Inicio bloque de código que interpreta las entradas de la etiqueta y devuelve strings completos

    //Toma todos los campos de la etiqueta y los hace coincidir en un texto coherente para su reproduccción o en caso de compartirlo
    protected String Variatext(String name, String artist, String time, String genre, String age, String info){




        if (time.equals(getResources().getString(R.string.SA_other))){ //Si la época está marcada como "Otro", se salta esa parte

            if(genre.equals(getResources().getString(R.string.SA_other))){//Si la época y el género están marcados como "Otro" entonces se salta ambas partes

                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);


            }else{//Si sólo está la época marcada como "Otro", entonces se adiciona la parte del género


                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.variagenret)).concat(" ").concat(genre).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);

            }


        }else{


            if(genre.equals(getResources().getString(R.string.SA_other))){//si solo el género están marcados como "Otro" entonces se salta ambas partes

                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.variatime)).concat(" ").concat(time).concat(" ")
                        .concat(infoTime).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);


            }else{//No falta nada, por lo tanto se utilizan todos los campos


                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.variatime)).concat(" ").concat(time).concat(" ")
                        .concat(infoTime).concat(" ")
                        .concat(getResources().getString(R.string.variagenret)).concat(" ").concat(genre).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);

            }


        }


    }



    protected String InterpretGenre(String a){//Interpreta el género de la obra tomando del string de spinner la posición de la selección

        int selected = Integer.parseInt(a);
        String[] genre = getResources().getStringArray(R.array.opc_genre);
        return genre[selected];

    }

    protected String InterpretTime(String a){//Interpreta el época de la obra tomando del string de
                                            // spinner la posición de la selección y además ajusta la fotografía representativa de cada época junto a su descripción

        int selected = Integer.parseInt(a);
        String[] time = getResources().getStringArray(R.array.opc_time);
        ImageView art = (ImageView) findViewById(R.id.image_art);

        switch (selected){

            case 0:
                infoTime = getResources().getString(R.string.variatime00);

                art.setImageResource(R.drawable.img00);
                break;

            case 1:
                infoTime = getResources().getString(R.string.variatime01);
                art.setImageResource(R.drawable.img01);

                break;


            case 2:
                infoTime = getResources().getString(R.string.variatime02);
                art.setImageResource(R.drawable.img02);
                break;

            case 3:
                infoTime = getResources().getString(R.string.variatime03);
                art.setImageResource(R.drawable.img03);
                break;

            case 4:
                infoTime = getResources().getString(R.string.variatime04);
                art.setImageResource(R.drawable.img04);
                break;

            case 5:
                infoTime = getResources().getString(R.string.variatime05);
                art.setImageResource(R.drawable.img05);
                break;

            case 6:
                infoTime = getResources().getString(R.string.variatime06);
                art.setImageResource(R.drawable.img06);
                break;

            case 7:
                infoTime = getResources().getString(R.string.variatime07);

                art.setImageResource(R.drawable.img07);
                break;

            case 8:
                infoTime = getResources().getString(R.string.variatime04);
                art.setImageResource(R.drawable.img08);
                break;
            case 9:
                infoTime = getResources().getString(R.string.variatime09);
                art.setImageResource(R.drawable.img09);
                break;
            case 10:
                infoTime = getResources().getString(R.string.variatime10);
                art.setImageResource(R.drawable.img10);
                break;
            case 11:
                infoTime = getResources().getString(R.string.variatime11);
                art.setImageResource(R.drawable.img11);
                break;
            case 12:
                infoTime = getResources().getString(R.string.variatime12);
                art.setImageResource(R.drawable.img12);
                break;
            case 13:
                infoTime = getResources().getString(R.string.variatime13);
                art.setImageResource(R.drawable.img13);
                break;

            case 14:
                infoTime = getResources().getString(R.string.variatime14);
                art.setImageResource(R.drawable.img14);
                break;


            case 15:
                infoTime = getResources().getString(R.string.variatime15);
                art.setImageResource(R.drawable.img15);
                break;


            case 16:
                infoTime = getResources().getString(R.string.variatime16);
                art.setImageResource(R.drawable.img16);

                break;


            case 17:
                infoTime = getResources().getString(R.string.variatime17);
                art.setImageResource(R.drawable.img17);
                break;


            case 18:
                infoTime = getResources().getString(R.string.variatime18);
                art.setImageResource(R.drawable.img18);
                break;


            case 19:
                infoTime = getResources().getString(R.string.variatime19);
                art.setImageResource(R.drawable.img19);
                break;


            case 20:
                infoTime = getResources().getString(R.string.variatime20);
                art.setImageResource(R.drawable.img20);
                break;


            case 21:
                infoTime = getResources().getString(R.string.variatime21);
                art.setImageResource(R.drawable.img21);
                break;


            case 22:
                infoTime = getResources().getString(R.string.variatime22);
                art.setImageResource(R.drawable.img22);
                break;


            case 23:
                infoTime = getResources().getString(R.string.variatime23);
                art.setImageResource(R.drawable.img23);
                break;


            case 24:
                infoTime = getResources().getString(R.string.variatime24);
                art.setImageResource(R.drawable.img24);
                break;


            case 25:
                infoTime = getResources().getString(R.string.variatime25);
                art.setImageResource(R.drawable.img25);
                break;


            case 26:
                infoTime = getResources().getString(R.string.variatime25);
                art.setImageResource(R.drawable.img26);
                break;



            case 27:

                break;







        }

        return time[selected];
    }
}
