package myappunab.dimelo3;

import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;

import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;

import android.util.Log;

import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

public class SaveNFC extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Boolean passed = false; //Indica si ejecutar la instancia NFC o no
    Spinner SP_save_genre, SP_save_time; //Declaración de los Spinner (o Combobox)
    EditText name,autor,age,info; //Los campos que se llenan manualmente para cada obra
    String information; //El String que contiene la información general de la obra, luego del tratamiento para escribir en la etiqueta
    NfcAdapter nfcAdapter; //El adaptador NFC que maneja las intancias

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Inicio código autogenerado
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_nfc);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //Fin código autogenerado

        //Inicio de la construcción de los spinners
        SP_save_genre = (Spinner) findViewById(R.id.SP_save_genre);
        SP_save_time = (Spinner) findViewById(R.id.Sp_save_time);

        SP_save_genre.setOnItemSelectedListener(this);
        SP_save_time.setOnItemSelectedListener(this);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.SP_save_genre, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Fin de la construcción de los spinners


        //Inicio declaración de los EditText del diseño xml en el código Java

        name = (EditText)findViewById(R.id.ET_save_name);
        autor = (EditText)findViewById(R.id.ET_save_autor);
        age = (EditText)findViewById(R.id.ET_save_age);
        info = (EditText)findViewById(R.id.ET_save_info);

        //Fin declaración de los EditText del diseño xml en el código Java








//Programación del botón flotante
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                //Si no hay campos completables manualmente vacíos, entonces entra
                if (!name.getText().toString().equals("")&&!autor.getText().toString().equals("")&&!age.getText().toString().equals("")&&!info.getText().toString().equals("")){

                    //Genera la variable information con toda la información de la etiqueta
                    information = "".concat(name.getText()+"").concat("/").concat(autor.getText()+"")
                            .concat("/").concat(SP_save_time.getSelectedItemPosition()+"").concat("/").concat(SP_save_genre.getSelectedItemPosition()+"").concat("/").concat(age.getText()+"")
                            .concat("/").concat(info.getText()+"");


                    //Si el largo de la información supera a 710, considerando como referencia las etiquetas de prueba que soportan 716 caracteres, entonces no permite que se grabe. Si no lo supera, lo permite
                    if(information.length() <= 710){

                        Snackbar.make(view, getResources().getString(R.string.tag_savesmartphone), Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();

                        passed = true;

                    }else { //Indica el número de caracteres por sobre el límite que tiene el usuario

                        int count = information.length() - 710;
                        Toast.makeText(SaveNFC.this,getResources().getString(R.string.tag_savelimit1) +" " +count + " " +getResources().getString(R.string.tag_savelimit2), Toast.LENGTH_LONG).show();


                    }



                }else { //Indica que existen campos vacíos, por lo tanto no se puede llenar la etiqueta

                    Toast.makeText(SaveNFC.this, getResources().getString(R.string.tag_savevoid), Toast.LENGTH_LONG).show();



                }



            }
        });


        //Inicio bloque te código de grabado NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this); //Se declara el adaptador NFC para el manejo de éste


    }



    @Override
    protected void onResume() {
        super.onResume();

        enableForegroundDispatchSystem();
    }

    @Override
    protected void onPause() {
        super.onPause();

        disableForegroundDispatchSystem();
    }

    @Override

    //Se declara la intención del grabado NFC
    protected void onNewIntent(Intent intent) {


        //Si passed es verdadero, permite la instancia. Este passed es sólo verdadero si el contenido de la etiqueta está validado
        if (passed) {
            super.onNewIntent(intent);

            if (intent.hasExtra(NfcAdapter.EXTRA_TAG)) {
//                Toast.makeText(this, "NfcIntent!", Toast.LENGTH_SHORT).show(); //Código de prueba para comprobar la intención

                Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                NdefMessage ndefMessage = createNdefMessage(information);

                writeNdefMessage(tag, ndefMessage); //Grabado de la etiqueta en el métiodo writeNdefMessage
            }
        }

    }


    //Habilita el uso del NFC para grabar la etiqueta
    private void enableForegroundDispatchSystem() {

        Intent intent = new Intent(this, SaveNFC.class).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        IntentFilter[] intentFilters = new IntentFilter[]{};

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, null);
    }


    //Desabilita el uso del NFC para grabar la etiqueta (permitiría leer)
    private void disableForegroundDispatchSystem() {
        nfcAdapter.disableForegroundDispatch(this);
    }


    //Formatea la etiqueta NFC, borrando antes a información contenida para luego grabar la nueva información
    private void formatTag(Tag tag, NdefMessage ndefMessage) {
        try {

            NdefFormatable ndefFormatable = NdefFormatable.get(tag);

            if (ndefFormatable == null) { //Comprueba la capacidad de formateo
                Toast.makeText(this, getResources().getString(R.string.tag_noformatable), Toast.LENGTH_SHORT).show();
                return;
            }

            //Prepara el formateo de la etiqueta
            ndefFormatable.connect();
            ndefFormatable.format(ndefMessage); //formatea
            ndefFormatable.close();
            //Cierra el formateo de la etiqueta

            Toast.makeText(this, getResources().getString(R.string.tag_write), Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Log.e("formatTag", e.getMessage());
        }

    }


    //Escribe la etiqueta con el contenido de variable information
    private void writeNdefMessage(Tag tag, NdefMessage ndefMessage) {

        try {
            //Comprueba que la etiqueta está operativa
            if (tag == null) {
                Toast.makeText(this, getResources().getString(R.string.tag_nonull), Toast.LENGTH_SHORT).show();
                return;
            }

            Ndef ndef = Ndef.get(tag);

            //Obtiene la información contenida en la etiqueta y la formatea
            if (ndef == null) {
                formatTag(tag, ndefMessage);
            } else {
                ndef.connect(); //Conecta con la etiqueta

                if (!ndef.isWritable()) {//Si la etiqueta no se puede escribir, entonces termina
                    Toast.makeText(this, getResources().getString(R.string.tag_nowrite), Toast.LENGTH_SHORT).show();

                    ndef.close();
                    return;
                }
                //En caso de pasar estas pruebas, la etiqueta NFC se graba con el mensaje de information, contenido en la variable ndefMessage
                ndef.writeNdefMessage(ndefMessage);
                ndef.close();//Se cierra la etiqueta

                Toast.makeText(this, getResources().getString(R.string.tag_write), Toast.LENGTH_SHORT).show(); //Indica que la etiqueta fue escrita con éxito

            }

        } catch (Exception e) {
            Log.e("writeNdefMessage", e.getMessage());
        }

    }


    private NdefRecord createTextRecord(String content) {
        try {
            byte[] language;
            language = Locale.getDefault().getLanguage().getBytes("UTF-8");

            final byte[] text = content.getBytes("UTF-8");
            final int languageSize = language.length;
            final int textLength = text.length;
            final ByteArrayOutputStream payload = new ByteArrayOutputStream(1 + languageSize + textLength);

            payload.write((byte) (languageSize & 0x1F));
            payload.write(language, 0, languageSize);
            payload.write(text, 0, textLength);

            return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], payload.toByteArray());

        } catch (UnsupportedEncodingException e) {
            Log.e("createTextRecord", e.getMessage());
        }
        return null;
    }


    private NdefMessage createNdefMessage(String content) {

        NdefRecord ndefRecord = createTextRecord(content);

        NdefMessage ndefMessage = new NdefMessage(new NdefRecord[]{ndefRecord});

        return ndefMessage;
    }

    //Fin bloque te código de grabado NFC

    //Inicio bloques autogenerados para los spinners
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        //En caso de ser seleccionado una opción, desencadena otra (Usualmente las opciones de otro spinner)
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

        //En caso de no seleccionar nada, no aplicable al proyecto actual pues se da la opción de "otro" en el spinner principal, para evitar que quede en blanco, aparte de no permitir que quede en blanco

    }
    //Fin bloques autogenerados para los spinners
}
