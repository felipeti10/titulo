package myappunab.dimelo3;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.UnsupportedSchemeException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    NfcAdapter nfcAdapter; //variable global para el NFC
    int form = 5; //número de campos existentes en las etiquetas (actualmente 5)


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //Save es el botón que inicia la intención para iniciar la pantalla SaveNFC
        Button save = (Button)findViewById(R.id.Bt_save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //Intención de que inicie la pantalla SaveNFC
                Intent intent = new Intent(view.getContext(), SaveNFC.class);
                startActivity(intent);


            }
        });

        //Inicio del bloque de manejo de NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter != null && nfcAdapter.isEnabled()) { //verifica que el NFC esté activado (previamente se solicitan permisos)

        //

        }else {//verifica que el NFC está desactivado
            //Indica que se encienda el NFC si está desactivado
            Toast.makeText(this, getResources().getString(R.string.tag_nfcactive), Toast.LENGTH_LONG).show();

        }

    }

        //Declarar instancia NFC, importante para verificar interacción entre teléfono y etiqueta
        @Override
    protected void onNewIntent(Intent intent) {

            super.onNewIntent(intent);

            if(intent.hasExtra(NfcAdapter.EXTRA_TAG)){ //verifica la intención

                Parcelable[] parcelables = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES); //Instancia para ver el contenido de la etiqueta

                if(parcelables != null && parcelables.length > 0)//verifica que no esté vacía
                {
                    readTextFromMessage((NdefMessage) parcelables[0]);//Lee la etiqueta NFC
                }else{
                    Toast.makeText(this, getResources().getString(R.string.tag_nosupport), Toast.LENGTH_SHORT).show();//La etiqueta estpa vacía o no se puede mostrar
                }


            }

    }

    private void readTextFromMessage(NdefMessage ndefMessage) { //método para leer le mensaje

        NdefRecord[] ndefRecords = ndefMessage.getRecords(); //

        if (ndefRecords != null && ndefRecords.length>0){//verifica que el mensaje no esté vacío

            NdefRecord ndefRecord = ndefRecords [0];

            String tagContent = getTextFromNdefRecord(ndefRecord);//guarda el contenido de la etiqueta en tagcontent

            if (passed(tagContent)){

                Intent intent2 = new Intent(this, ScrollingActivity.class); //declaro una intención de ir art la clase scrollingactivity


                intent2.putExtra("info", tagContent);//declaro variable que se comparte con la siguiente actividad

                startActivity(intent2); //inicio la actividad3
            }else{

                Toast.makeText(this,getResources().getString(R.string.tag_nosupport),Toast.LENGTH_LONG).show();

            }





        }else{

            Toast.makeText(this, getResources().getString(R.string.tag_norecord), Toast.LENGTH_SHORT).show();

        }

    }

    protected boolean passed(String InfoTag){ //Verifica que la etiqueta que se esta leyendo está grabada correctamente, evita que la app se caiga

        String[] split = InfoTag.toString().split("/"); //Separa la etiqueta en split


        for(int a = 0; a < split.length;a++){

            if (split[a].toString().length()<1 || split.length<form){//Verifica que cada campo esté lleno y que esten la cantidad de campos correctos

                return  false; //Si algo de esto falla, entonces retorna falso y no lee la etiqueta
            }

        }



        return true; //Si está correcto, entonces entra y lee la etiqueta



    }



    @Override
    protected void onResume() {
        super.onResume();

        enableForegroundDispatchSystem();
    }

    @Override
    protected void onPause() {
        super.onPause();

        disableForegroundDispatchSystem();
    }




    private void enableForegroundDispatchSystem(){//Activa las opciones para NFC

        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        IntentFilter[] intentFilters = new IntentFilter[]{};

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, null);

    }

    private void disableForegroundDispatchSystem(){

    nfcAdapter.disableForegroundDispatch(this); //Desactiva las opciones para NFC
    }





    public String getTextFromNdefRecord(NdefRecord ndefRecord) //para leer, obtiene el mensaje desde otro formato
    {
        String tagContent = null;
        try {
            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16";
            int languageSize = payload[0] & 0063;
            tagContent = new String(payload, languageSize + 1,
                    payload.length - languageSize - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("getTextFromNdefRecord", e.getMessage(), e);
        }
        return tagContent;
    }



//Fin de bloque de manejo NFC


}

















