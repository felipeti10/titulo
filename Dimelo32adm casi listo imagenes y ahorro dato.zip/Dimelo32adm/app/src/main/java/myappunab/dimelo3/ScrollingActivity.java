package myappunab.dimelo3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ScrollingActivity extends AppCompatActivity {

    TextToSpeech tts;
    String url;
    String infoTime = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Llamo art la intencion
        Bundle bundle = getIntent().getExtras();

        //pongo en el textview lo que debería
        String info = bundle.getString("info");//Tomo lo que hay en info
        final String Lb_info = info;//por orden
        final String[] split = Lb_info.split("/");





        try{

            split[3] = InterpretGenre(split[3]);
            split[2] = InterpretTime(split[2]);

        }catch (Exception e){

            Toast.makeText(ScrollingActivity.this,"No se pudo cargar el género!, ¡Lo siento!",Toast.LENGTH_SHORT).show();
        }


        getSupportActionBar().setTitle(split[0]);

        TextView artist = (TextView)findViewById(R.id.Lb_artist);//llamo ar mi label y lo dejo listo para editarse
        artist.setText(split[1]);//se edita con lo que contiene Lb_artist

        TextView time = (TextView)findViewById(R.id.Lb_time);//llamo ar mi label y lo dejo listo para editarse
        time.setText(split[2]);//se edita con lo que contiene Lb_artist

        TextView genre = (TextView)findViewById(R.id.Lb_genre);//llamo ar mi label y lo dejo listo para editarse
        genre.setText(split[3]);//se edita con lo que contiene Lb_genre

        TextView age = (TextView)findViewById(R.id.Lb_age);//llamo a mi label y lo dejo listo para editarse
        age.setText(split[4]);//se edita con lo que contiene Lb_age

        TextView out = (TextView)findViewById(R.id.Lb_info);//llamo ar mi label y lo dejo listo para editarse
        out.setText(split[5]);//se edita con lo que contiene Lb_info

        url = "https://www.google.cl/?gws_rd=ssl#q=".concat(split[0]).concat("+").concat(split[1]);
        url = url.replace(" ","+");


        //Inicio código para compartir

        Button im = (Button) findViewById(R.id.Bt_share);

        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "¡Compartiendo!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();


                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, Variatext(split[0],split[1],split[2],split[3],split[4],split[5]) + "\n" + url);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

            }
        });



        im.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, "¡Presiona para compartir con tus amigos!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código para compartir

        //Inicio código buscar en google




        Button sr = (Button) findViewById(R.id.Bt_search);

        sr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "¡Buscando!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();




                //HACER UNA VARIABLE URL Y ARMARLA CON UN STRING
                Uri uriURL = Uri.parse(url);
                Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriURL);
                startActivity(launchBrowser);


            }
        });


        sr.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, "¡Presiona para buscar más en Google!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código buscar en google

        //Inicio código Text To Speech

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {

                }
            }
        });

        String name = bundle.getString("name");
        setTitle(name);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tts.speak(Variatext(split[0],split[1],split[2],split[3],split[4],split[5]),TextToSpeech.QUEUE_FLUSH, null);
                Snackbar.make(view, "Reproduciendo audio", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        }




        );
    }

    protected String Variatext(String name, String artist, String time, String genre, String age, String info){


        //String Inicio = getResources().getString(R.string.variatext1);


        if (time.equals("Otro")){

            if(genre.equals("Otro")){

                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);


            }else{


                return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.variagenret)).concat(" ").concat(genre).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);

            }


        }else{

            return "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                    .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                    .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                    .concat(getResources().getString(R.string.variatime)).concat(" ").concat(time).concat(" ")
                    .concat(infoTime).concat(" ")
                    .concat(getResources().getString(R.string.variagenret)).concat(" ").concat(genre).concat(" ")
                    .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);

        }


    }



    protected String InterpretGenre(String a){

        int selected = Integer.parseInt(a);

        switch (selected){

            case 0:

                return "Paisaje";

            case 1:

                return "Retrato";

            case 2:

                return "Bodegón";

            case 3:

                return "Desnudo";

            case 4:

                return "Escena de género";

            case 5:

                return "Pintura histórica";

            case 6:

                return "Escena de género";

            case 7:

                return "Otro";







        }

        return "No especificado";
    }

    protected String InterpretTime(String a){

        int selected = Integer.parseInt(a);
        ImageView art = (ImageView) findViewById(R.id.image_art);

        switch (selected){

            case 0:
                infoTime = getResources().getString(R.string.variatime00);
                art.setImageResource(R.drawable.img00);
                return "Estilo de fotografía";

            case 1:
                infoTime = getResources().getString(R.string.variatime01);
                art.setImageResource(R.drawable.img01);

                return "Arte abstracto";


            case 2:
                infoTime = getResources().getString(R.string.variatime02);
                art.setImageResource(R.drawable.img02);
                return "Arte figurativo";

            case 3:
                infoTime = getResources().getString(R.string.variatime03);
                art.setImageResource(R.drawable.img03);
                return "Arte retro";

            case 4:
                infoTime = getResources().getString(R.string.variatime04);
                art.setImageResource(R.drawable.img04);
                return "surrealismo contemporáneo";

            case 5:
                infoTime = getResources().getString(R.string.variatime05);
                art.setImageResource(R.drawable.img05);
                return "Arte asiático";

            case 6:
                infoTime = getResources().getString(R.string.variatime06);
                art.setImageResource(R.drawable.img06);
                return "Pop Art";

            case 7:
                infoTime = getResources().getString(R.string.variatime07);

                art.setImageResource(R.drawable.img07);
                return "Arte antiguo";

            case 8:
                infoTime = getResources().getString(R.string.variatime04);
                art.setImageResource(R.drawable.img08);
                return "Surrealismo";
            case 9:
                infoTime = getResources().getString(R.string.variatime09);
                art.setImageResource(R.drawable.img09);
                return "Arte medieval";
            case 10:
                infoTime = getResources().getString(R.string.variatime10);
                art.setImageResource(R.drawable.img10);
                return "Cubismo";
            case 11:
                infoTime = getResources().getString(R.string.variatime11);
                art.setImageResource(R.drawable.img11);
                return "Fauvismo";
            case 12:
                infoTime = getResources().getString(R.string.variatime12);
                art.setImageResource(R.drawable.img12);
                return "Simbolismo";
            case 13:
                infoTime = getResources().getString(R.string.variatime13);
                art.setImageResource(R.drawable.img13);
                return "Expresionismo";

            case 14:
                infoTime = getResources().getString(R.string.variatime14);
                art.setImageResource(R.drawable.img14);
                return "Puntillismo o neoimpresionismo";


            case 15:
                infoTime = getResources().getString(R.string.variatime15);
                art.setImageResource(R.drawable.img15);
                return "Post impresionismo";


            case 16:
                infoTime = getResources().getString(R.string.variatime16);
                art.setImageResource(R.drawable.img16);

                return "Impresionismo";


            case 17:
                infoTime = getResources().getString(R.string.variatime17);
                art.setImageResource(R.drawable.img17);
                return "Realismo";


            case 18:
                infoTime = getResources().getString(R.string.variatime18);
                art.setImageResource(R.drawable.img18);
                return "Arte victoriano";


            case 19:
                infoTime = getResources().getString(R.string.variatime19);
                art.setImageResource(R.drawable.img19);
                return "Romanticismo";


            case 20:
                infoTime = getResources().getString(R.string.variatime20);
                art.setImageResource(R.drawable.img20);
                return "Clasisismo";


            case 21:
                infoTime = getResources().getString(R.string.variatime21);
                art.setImageResource(R.drawable.img21);
                return "Rococó";


            case 22:
                infoTime = getResources().getString(R.string.variatime22);
                art.setImageResource(R.drawable.img22);
                return "Barroco";


            case 23:
                infoTime = getResources().getString(R.string.variatime23);
                art.setImageResource(R.drawable.img23);
                return "Minierismo";


            case 24:
                infoTime = getResources().getString(R.string.variatime24);
                art.setImageResource(R.drawable.img24);
                return "Arte gótico";


            case 25:
                infoTime = getResources().getString(R.string.variatime25);
                art.setImageResource(R.drawable.img25);
                return "Renacimiento";


            case 26:
                infoTime = getResources().getString(R.string.variatime25);
                art.setImageResource(R.drawable.img26);
                return "Bajo renacimiento";



            case 27:

                return "Otro";







        }

        return "No especificado";
    }
}
