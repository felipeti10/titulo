package myappunab.dimelo3;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.UnsupportedSchemeException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    NfcAdapter nfcAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Manejo de NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter != null && nfcAdapter.isEnabled()) {


        }else {
            //Indica que se encienda el NFC si está desactivado
            Toast.makeText(this, "Active el NFC por favor!", Toast.LENGTH_LONG).show();

        }




    }


        //Ver si se declara una instancia NFC (posible error)
        @Override
    protected void onNewIntent(Intent intent) {

            super.onNewIntent(intent);

            if(intent.hasExtra(NfcAdapter.EXTRA_TAG)){

                Toast.makeText(this, "NFC Intención!", Toast.LENGTH_SHORT).show();

                Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                NdefMessage ndefMessage = createNdefMessage("My string content!");
                writeNdefMessage(tag, ndefMessage);
            }


    }



    @Override
    protected void onResume() {
        super.onResume();

        enableForegroundDispatchSystem();
    }

    @Override
    protected void onPause() {
        super.onPause();

        disableForegroundDispatchSystem();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private void enableForegroundDispatchSystem(){

        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        IntentFilter[] intentFilters = new IntentFilter[]{};

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, null);

    }

    private void disableForegroundDispatchSystem(){

    nfcAdapter.disableForegroundDispatch(this);
    }

    private void formarTag(Tag tag, NdefMessage ndefMessage){

        try{

            NdefFormatable ndefFormatable = NdefFormatable.get(tag);

            if(ndefFormatable == null){
                Toast.makeText(this, "El Tag no se puede formatear!",Toast.LENGTH_SHORT).show();
                return;
            }

            ndefFormatable.connect();
            ndefFormatable.format(ndefMessage);
            ndefFormatable.close();

            Toast.makeText(this, "El tag fue escrito", Toast.LENGTH_SHORT).show();

        }catch(Exception e){

            Log.e("FormatTag", e.getMessage());

        }

    }


    private void writeNdefMessage(Tag tag, NdefMessage ndefMessage){


        try {

            if (tag == null){


                Toast.makeText(this, "El tag no puede estar vacío", Toast.LENGTH_SHORT).show();
                return;

            }


            Ndef ndef = Ndef.get(tag);

            if (ndef == null){

                //formatea y escribe el mensaje
                formarTag(tag, ndefMessage);
            } else {

                ndef.connect();

                if (!ndef.isWritable()){
                    Toast.makeText(this, "El tag no se puede escribir", Toast.LENGTH_SHORT).show();
                    ndef.close();
                    return;


                }


                ndef.writeNdefMessage(ndefMessage);
                ndef.close();

                Toast.makeText(this, "El tag fue escrito", Toast.LENGTH_SHORT).show();



            }



        } catch (Exception e){


            Log.e("writeNdefMessage", e.getMessage());
        }




    }

    private NdefRecord createTextRecord(String content) {

        try{

            byte[] language;
            language = Locale.getDefault().getLanguage().getBytes("UTF-8");

            final byte[] text = content.getBytes("UTF-8");
            final int languageSize = language.length;
            final int textLength = text.length;
            final ByteArrayOutputStream payload = new ByteArrayOutputStream(1 + languageSize + textLength);

            payload.write((byte) (languageSize & 0x1F));
            payload.write(language, 0, languageSize);
            payload.write(text, 0, textLength);

            return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new  byte[0], payload.toByteArray());

        } catch (UnsupportedEncodingException e){

            Log.e("createTextRecord", e.getMessage());



        }
        return  null;



    }



    private NdefMessage createNdefMessage(String content) {

        NdefRecord ndefRecord = createTextRecord(content);

        NdefMessage ndefMessage = new NdefMessage(new NdefRecord[]{ ndefRecord });

        return ndefMessage;

    }



}


        //Manejo de la interfaz gráfica
/*        final EditText textinfo, textname; //declaro el edittext
        textinfo = (EditText) findViewById(R.id.Tf_info); //Declaro cuál edittext tomo
        textname = (EditText) findViewById(R.id.Tf_name);

        ImageButton btn = (ImageButton) findViewById(R.id.Bt_nfc);

        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ScrollingActivity.class); //declaro una intención de ir a la clase scrollingactivity

                intent.putExtra("info", textinfo.getText().toString());//declaro variable que se comparte con la siguiente actividad
                intent.putExtra("name",textname.getText().toString());
                startActivity(intent); //inicio la actividad
            }
        });
*/













