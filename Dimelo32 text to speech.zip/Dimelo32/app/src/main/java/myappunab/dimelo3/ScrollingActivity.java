package myappunab.dimelo3;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

public class ScrollingActivity extends AppCompatActivity {

    TextToSpeech tts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Llamo a la intencion
        Bundle bundle = getIntent().getExtras();

        //pongo en el textview lo que debería
        String info = bundle.getString("info");//Tomo lo que hay en info
        final String Lb_info = info;//por orden
        TextView out = (TextView)findViewById(R.id.Lb_info);//llamo a mi label y lo dejo listo para editarse
        out.setText(Lb_info);//se edita con lo que contiene Lb_info

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {

                }
            }
        });

        String name = bundle.getString("name");
        setTitle(name);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tts.speak(Lb_info,TextToSpeech.QUEUE_FLUSH, null);
                Snackbar.make(view, "Reproduciendo audio", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        }




        );
    }
}
