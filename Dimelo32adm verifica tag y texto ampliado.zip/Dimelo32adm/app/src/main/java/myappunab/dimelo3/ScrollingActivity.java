package myappunab.dimelo3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class ScrollingActivity extends AppCompatActivity {

    TextToSpeech tts;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Llamo art la intencion
        Bundle bundle = getIntent().getExtras();

        //pongo en el textview lo que debería
        String info = bundle.getString("info");//Tomo lo que hay en info
        final String Lb_info = info;//por orden
        final String[] split = Lb_info.split("/");

        getSupportActionBar().setTitle(split[0]);

        TextView artist = (TextView)findViewById(R.id.Lb_artist);//llamo ar mi label y lo dejo listo para editarse
        artist.setText(split[1]);//se edita con lo que contiene Lb_artist

        TextView genre = (TextView)findViewById(R.id.Lb_genre);//llamo ar mi label y lo dejo listo para editarse
        genre.setText(split[2]);//se edita con lo que contiene Lb_genre

        TextView age = (TextView)findViewById(R.id.Lb_age);//llamo a mi label y lo dejo listo para editarse
        age.setText(split[3]);//se edita con lo que contiene Lb_age

        TextView out = (TextView)findViewById(R.id.Lb_info);//llamo ar mi label y lo dejo listo para editarse
        out.setText(split[4]);//se edita con lo que contiene Lb_info


        //Inicio código para compartir

        Button im = (Button) findViewById(R.id.Bt_share);

        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "¡Compartiendo!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();


                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, Variatext(split[0],split[1],split[2],split[3],split[4]));
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

            }
        });



        im.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, "¡Presiona para compartir con tus amigos!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código para compartir

        //Inicio código buscar en google

        url = "https://www.google.cl/?gws_rd=ssl#q=".concat(split[0]).concat("+").concat(split[1]);
        url = url.replace(" ","+");


        Button sr = (Button) findViewById(R.id.Bt_search);

        sr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "¡Buscando!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();




                //HACER UNA VARIABLE URL Y ARMARLA CON UN STRING
                Uri uriURL = Uri.parse(url);
                Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriURL);
                startActivity(launchBrowser);


            }
        });


        sr.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Snackbar.make(view, "¡Presiona para buscar más en Google!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                return false;
            }
        });

        //Fin código buscar en google

        //Inicio código Text To Speech

        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {

                }
            }
        });

        String name = bundle.getString("name");
        setTitle(name);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tts.speak(Variatext(split[0],split[1],split[2],split[3],split[4]),TextToSpeech.QUEUE_FLUSH, null);
                Snackbar.make(view, "Reproduciendo audio", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        }




        );
    }

    protected String Variatext(String name, String artist, String genre, String age, String info){


        //String Inicio = getResources().getString(R.string.variatext1);

        String completext = "".concat(getResources().getString(R.string.varia1p1)).concat(" ").concat(age).concat(" ")
                        .concat(getResources().getString(R.string.varia1p2)).concat(" ").concat(name).concat(" ")
                        .concat(getResources().getString(R.string.varia1p3)).concat(" ").concat(artist).concat(" ")
                        .concat(getResources().getString(R.string.variagenret)).concat(" ").concat(genre).concat(" ")
                        .concat(getResources().getString(R.string.varia2p2)).concat(" ").concat(info);



        return completext;
    }
}
